-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2025 at 04:39 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `search_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `category` varchar(100) NOT NULL,
  `stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `category`, `stock`) VALUES
(1, 'Ducky One 3 Mini', 'Description: Compact, high-performance 60% keyboard with hot-swappable switches, vibrant RGB lighting, and a solid build. Perfect for gaming and productivity', 119.90, 'keyboard', 100),
(2, 'Keychron K6', 'Compact 65% layout with Bluetooth & wired connectivity, hot-swappable switches, and RGB backlight. Ideal for work and gaming.', 89.99, 'keyboards', 50),
(3, 'Corsair K95 RGB Platinum', 'Full-sized keyboard with dedicated macro keys, per-key RGB lighting, and Cherry MX switches. Built for performance and durability.', 199.99, 'keyboards', 30),
(4, 'Leopold FC660M', 'Compact and minimalist with top-tier build quality, PBT keycaps, and reliable Cherry MX switches. Perfect for enthusiasts and professionals.', 139.99, 'keyboards', 40),
(5, 'Drop ALT V1', 'Compact, hot-swappable keyboard with an aluminum frame, customizable RGB, and premium build quality. Perfect for gaming and typing.', 179.99, 'keyboards', 35),
(6, 'Varmilo Sakura R2 87', 'Elegant tenkeyless keyboard with Sakura-themed design, high-quality PBT keycaps, and smooth mechanical switches. Perfect for aesthetics and performance.', 159.99, 'keycaps', 25),
(7, 'Akko Macaw Keycap Set', 'Vibrant Macaw-themed keycaps made from durable PBT with an ASA profile for a comfortable typing experience. Compatible with most mechanical keyboards.', 69.99, 'keycaps', 60),
(8, 'Drop + Matt3o MT3 Dev/TTY Keycap Set', 'Retro-styled keycaps with a sculpted MT3 profile, high-quality PBT material, and dye-sublimated legends. Designed for a comfortable, vintage typing feel.', 110.00, 'keycaps', 40),
(9, 'Drop + RedSuns GMK Red Samurai Keycap Set', 'Bold and striking keycap set with a Red Samurai-inspired design, GMK’s premium ABS plastic, and Cherry profile for a smooth, high-quality typing experience.', 149.99, 'keycaps', 30),
(10, 'PBTfans Neon Keycap Set', 'High-quality PBT keycaps with a vibrant neon colorway, Cherry profile, and durable dye-sublimated legends. Perfect for adding a bold touch to any keyboard.', 89.99, 'keycaps', 45),
(11, 'Akko Black & Pink Keycap Set', 'Stylish black and pink keycap set made from durable PBT with an ergonomic ASA profile. Ideal for a sleek, modern look and comfortable typing.', 59.99, 'keycaps', 55),
(12, 'Tiger Sketch Keycap Set', 'Unique artistic keycaps featuring hand-drawn tiger designs, durable PBT material, and Cherry profile for a smooth typing experience. Perfect for a bold setup.', 74.99, 'keycaps', 50),
(13, 'Cherry MX Switch Set', 'Authentic Cherry MX switches available in various types (Red, Blue, Brown, etc.) for a customizable typing and gaming experience. Durable and reliable.', 39.99, 'switches', 50),
(14, 'Kailh Box Switch Set', 'Smooth and durable switches with a unique boxed design for dust and water resistance. Available in multiple variants for different typing preferences.', 29.99, 'switches', 60),
(15, 'Durock T1 Tactile 67g Teal Switch Set', 'Smooth tactile switches with a 67g actuation force, featuring a deep, thocky sound and minimal wobble. Ideal for a premium typing experience.', 45.99, 'switches', 40),
(16, 'Panda MX Unlubed Switch Set', 'Crisp and snappy tactile switches with a strong bump, perfect for a responsive typing experience. Unlubed for full customization.', 49.99, 'switches', 30),
(17, 'Drop + Invyr Holy Panda Mechanical Switch Set', 'Legendary tactile switches with a strong, snappy bump and a smooth feel. Perfect for enthusiasts seeking a premium typing experience.', 69.99, 'switches', 35),
(18, 'Gateron Yellow G Pro 3.0 Switch Set', 'Smooth and lightweight linear switches with factory pre-lubing for a buttery typing feel. Ideal for gaming and everyday use.', 27.99, 'switches', 55),
(19, 'ATTACK SHARK KS01 Keycap & Switch Puller', 'Dual-purpose tool for easy keycap and switch removal. Ergonomic design with a sturdy build, perfect for keyboard maintenance and customization.', 9.99, 'accessories', 60),
(20, 'Switch Puller', 'Compact and durable tool designed for easy removal of mechanical switches. Essential for hot-swappable keyboards and switch customization.', 6.99, 'accessories', 80),
(21, 'Keychron Keyboard Wooden Palm Rest', 'Ergonomic and stylish wooden palm rest designed for Keychron keyboards. Provides comfort and wrist support for long typing sessions.', 25.99, 'accessories', 30),
(22, 'Keycap Storage Display Box', 'Sleek, durable display box for organizing and showcasing your keycap sets. Perfect for enthusiasts looking to keep their keycaps safe and accessible.', 19.99, 'accessories', 40),
(23, 'Switch Lubricant', 'High-quality lubricant designed to reduce friction and enhance the smoothness of mechanical switches. Perfect for customizing and improving your keyboard\'s performance.', 8.99, 'accessories', 70),
(24, 'HyperX USB-C Coiled Cable', 'Premium coiled USB-C cable for mechanical keyboards. Durable and flexible design with a tangle-free experience, offering fast and reliable connectivity.', 19.99, 'accessories', 50),
(25, 'Corgi Fairlady Alice Keycap Set', 'Playful, high-quality keycap set inspired by the Fairlady Alice design, made from durable PBT material with vibrant colors and smooth Cherry profile for an enjoyable typing experience.', 99.99, 'diyKits', 40),
(26, 'KBD.fans Gaming Keyboard Kit', 'Customizable gaming keyboard kit with premium components, including a sturdy PCB and high-quality case. Perfect for enthusiasts who want to build a personalized mechanical keyboard.', 129.99, 'diyKits', 30),
(27, 'ACGAM Alice VIA Wireless DIY Kit', 'Customizable Alice layout wireless keyboard kit with VIA compatibility for easy key remapping. Perfect for enthusiasts seeking a unique, high-performance setup.', 159.99, 'diyKits', 25),
(28, 'Corne Cherry V3 Split Ergo DIY Kit', 'Split ergonomic keyboard kit featuring a customizable layout and Cherry MX switch compatibility. Perfect for those looking for a personalized, comfortable typing experience.', 57.99, 'diyKits', 35),
(29, 'Monsgeek DIY Keyboard Kit', 'Customizable DIY mechanical keyboard kit with a flexible layout, high-quality PCB, and sturdy build. Ideal for enthusiasts looking to create a personalized typing experience.', 99.99, 'diyKits', 45),
(30, 'TIDBIT Customizable 19-Key Numpad Kit', 'A versatile 19-key numpad kit with fully customizable keymapping. Ideal for productivity, gaming, or macros, offering a sleek and functional setup.', 49.99, 'diyKits', 50);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
